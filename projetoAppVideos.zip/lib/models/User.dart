class User {
  int? id;
  String name;
  String email;
  String password;

  User(this.id, this.name, this.email, this.password);

  User.noId(this.name, this.email, this.password);

}
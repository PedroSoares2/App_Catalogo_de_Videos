class Genre {
  int?  id;
  String name;

  Genre(this.name);

  Genre.withId(this.id, this.name);
}
class VideoGenre {
  int videoId;
  int genreId;

  VideoGenre(this.videoId, this.genreId);
}
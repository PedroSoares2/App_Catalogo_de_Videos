import 'package:app_videos/views/LoginView.dart';
import 'package:flutter/material.dart';


void main() {
  runApp(MaterialApp(
    title: "CloneFlix",
    debugShowCheckedModeBanner: false,
    home: Login(),
  ));
}